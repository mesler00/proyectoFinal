from setuptools import setup
setup (
   author= "Martina",
   author_email= "m%m99@gmail.com",
   description= "esto es el intento de un paquete redistribuible",
   version= "0.0.1",
   name= "1erpaquete",
   packages=['e-commerce']
)