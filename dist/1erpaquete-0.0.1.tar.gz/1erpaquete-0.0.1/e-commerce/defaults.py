from libro import Libro

BOOKS = [
    Libro('Harry Potter', 100.0)
]